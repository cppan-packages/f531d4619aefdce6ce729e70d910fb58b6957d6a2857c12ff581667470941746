static cmVS7FlagTable cmVS10RCFlagTable[] = {
  // Bool Properties
  { "NullTerminateStrings", "n", "", "true", 0 },

  { 0, 0, 0, 0, 0 }
};
